// Determine if Gutenberg is active
gpt_press_pro_gutenberg_active = ( ( typeof wp.data !== 'undefined' && typeof wp.data.dispatch( 'core/edit-post' ) !== 'undefined' ) ? true : false );

if ( gpt_press_pro_gutenberg_active && wp.data.dispatch( 'core/edit-post' ) !== null ) {

	if ( typeof gpt_press_pro_gutenberg != 'undefined' ) {

		// Remove the Permalink Panel, if we're using Gutenberg on Content Groups
		if ( gpt_press_pro_gutenberg.post_type == 'gpt-press-pro' ) {
			wp.data.dispatch( 'core/edit-post' ).removeEditorPanel( 'post-link' );
		}

	}

}