<div class="wrap">
    <h1 class="wp-heading-inline">
        <?php echo $this->base->plugin->displayName; ?>

        <span>
        	<?php
        	if ( isset( $keyword ) && isset( $keyword['keywordID'] ) ) {
        		_e( 'Edit Keyword', 'gpt-press-pro' );
        	} else {
        		_e( 'Add New Keyword', 'gpt-press-pro' );
        	}
        	?>
        </span>
    </h1>

    <?php
    // Button Links
    require_once( 'keywords-links.php' );

    // Output Success and/or Error Notices, if any exist
    $this->base->get_class( 'notices' )->output_notices();
    ?>
    
    <div class="wrap-inner">
	    <div id="poststuff">
	    	<div id="post-body" class="metabox-holder columns-1">
	    		<!-- Content -->
	    		<div id="post-body-content">
	    			<!-- Form Start -->
	    			<form class="<?php echo $this->base->plugin->name; ?>" name="post" method="post" action="admin.php?page=<?php echo $page; ?>&amp;cmd=form<?php echo ( isset( $_GET['id'] ) ? '&id=' . absint( $_GET['id'] ) : '' ); ?>" enctype="multipart/form-data">		
		    	    	<div id="normal-sortables" class="meta-box-sortables ui-sortable">                        
			                <div id="keyword-panel" class="postbox">
			                	<?php
			                	// Output if editing an existing Keyword
			                	if ( isset( $keyword ) && isset( $keyword['keywordID'] ) ) {
			                		?>
			                		<input type="hidden" name="keywordID" value="<?php echo $keyword['keywordID']; ?>" />
			                		<?php
			                	}
			                    ?>
			                    
			                    <h3 class="hndle"><?php _e( 'Keyword', 'gpt-press-pro' ); ?></h3>
			                    
			                    <div class="wpzinc-option">
			                    	<div class="left">
			                    		<label for="keyword"><?php _e( 'Keyword', 'gpt-press-pro' ); ?></label>
			                    	</div>
			                    	<div class="right">
			                    		<input type="text" name="keyword" id="keyword" value="<?php echo ( isset( $keyword['keyword'] ) ? $keyword['keyword'] : '' ); ?>" class="widefat" />
			                    	
				                    	<p class="description">
				                    		<?php _e( 'Buat sebuah Penanda Keyword yang unik, jangan pakai spasi dan karakter aneh - aneh.', 'gpt-press-pro' ); ?>
				                    	</p>
			                    	</div>
			                    </div>

			                    <div class="wpzinc-option">
			                    	<div class="left">
			                    		<label for="data"><?php _e( 'Terms', 'gpt-press-pro' ); ?></label>
			                    	</div>
			                    	<div class="right">
			                    		<textarea name="data" id="data" rows="10" class="widefat no-wrap" style="height:300px"><?php echo ( isset( $keyword['data'] ) ? $keyword['data'] : '' ); ?></textarea>
			                    	
				                    	<p class="description">
				                    		<?php _e( 'Tiap Kata atau frasa atau kalimat di atas yang akan dipakai secara bergantian berurutan saat membuat konten menggunakan tag templat Keyword di atas.', 'gpt-press-pro' ); ?>
				                    		<br />
				                    		<?php _e( '1 Kata / Frasa/ Kalimat per baris.', 'gpt-press-pro' ); ?>
				                    		<br />
				                    		<?php _e( 'If no Terms are entered, the plugin will try to automatically determine a list of similar terms based on the supplied keyword when you click Save.', 'gpt-press-pro' ); ?>
				                    	</p>
			                    	</div>
			                    </div>

			                    <?php
								// Upgrade Notice
								if ( class_exists( 'Gpt_Press' ) ) {
								    require( $this->base->plugin->folder . 'views/admin/keywords-form-upgrade.php' );
								}
								?>
			                    
			                    <div class="wpzinc-option">
		                    		<?php wp_nonce_field( 'save_keyword', $this->base->plugin->name . '_nonce' ); ?>
		                			<input type="submit" name="submit" value="<?php _e( 'Save', 'gpt-press-pro' ); ?>" class="button button-primary" />
			                    </div>
			                </div>
						</div>
						<!-- /normal-sortables -->
				    </form>
				    <!-- /form end -->
	    		</div>
	    		<!-- /post-body-content -->
	    	</div>
		</div>  
	</div>     
</div>