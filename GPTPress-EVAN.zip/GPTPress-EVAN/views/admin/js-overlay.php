<!-- JS Overlay -->
<div id="gpt-press-pro-overlay"></div>
<div id="gpt-press-pro-progress">
	<h2 class="title">
		<span class="text"></span>
		<div class="spinner"></div>		
	</h2>

	<div class="notices"></div>

	<p class="message"></p>

	<button class="close button"><?php _e( 'Close', 'gpt-press' ); ?></button>
</div>