<?php
/**
 * Outputs button links below the Header when in the Keywords section
 *
 * @since 	1.7.8
 */
?>
<a href="admin.php?page=<?php echo $page; ?>&amp;cmd=form" class="page-title-action"><?php _e( 'Tambah Keyword', 'gpt-press' ); ?></a>

<hr class="wp-header-end" />