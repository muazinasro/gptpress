<?php
/**
 * AJAX class
 * 
 * @package Page Generator Pro
 * @author  Tim Carr
 * @version 1.0.0
 */
class Gpt_Press_Pro_AJAX {

    /**
     * Holds the base object.
     *
     * @since   1.9.8
     *
     * @var     object
     */
    public $base;

    /**
     * Constructor
     *
     * @since   1.0.0
     *
     * @param   object $base    Base Plugin Class
     */
    public function __construct( $base ) {

        // Store base class
        $this->base = $base;

        // Generate: Authors
        add_action( 'wp_ajax_gpt_press_pro_search_authors', array( $this, 'search_authors' ) );

        // Generate
        add_action( 'wp_ajax_gpt_press_pro_generate', array( $this, 'generate' ) ); // Backward compat < 1.6.0
        add_action( 'wp_ajax_gpt_press_pro_generate_content', array( $this, 'generate_content' ) );
        add_action( 'wp_ajax_gpt_press_pro_generate_content_trash_generated_content', array( $this, 'trash_generated_content' ) );
        add_action( 'wp_ajax_gpt_press_pro_generate_content_delete_generated_content', array( $this, 'delete_generated_content' ) );
        add_action( 'wp_ajax_gpt_press_pro_generate_content_finished', array( $this, 'finished_generated_content' ) );
        
    }

    /**
     * Returns the maximum number of generated items to delete in a single AJAX
     * request, to prevent timeouts or server errors.
     *
     * @since   2.7.6
     *
     * @return  int     Limit
     */
    public function get_trash_delete_per_request_item_limit() {

        $limit = 500;

        /**
         * The maximum number of generated items to trash or delete in a single AJAX
         * request, to prevent timeouts or server errors.
         *
         * If there are more items to delete than the limit specified, the Plugin
         * will send synchronous requests until all items are deleted.
         *
         * @since   2.7.6
         */
        $limit = apply_filters( 'gpt_press_pro_ajax_delete_generated_count_number_of_items', $limit );

        // Return
        return absint( $limit );

    }

    /**
     * Searches for Authors for the given freeform text
     *
     * @since   1.8.3
     */
    public function search_authors() {

        // Get vars
        $query = sanitize_text_field( $_REQUEST['query'] );

        // Get results
        $users = new WP_User_Query( array(
            'search' => '*' . $query . '*',
        ) );

        // If an error occured, bail
        if ( is_wp_error( $users ) ) {
            return wp_send_json_error( $users->get_error_message() );
        }

        // Build array
        $users_array = array();
        $results = $users->get_results();
        if ( ! empty( $results ) ) {
            foreach ( $results as $user ) {
                $users_array[] = array(
                    'id'        => $user->ID,
                    'user_login'=> $user->user_login,
                );
            }
        }

        // Done
        wp_send_json_success( $users_array );

    }

    /**
     * Backward compat function for Page Generator Pro 1.6.0 and older.
     *
     * Passes the request to generate_content()
     *
     * @since   1.0.0
     */
    public function generate() {

        $this->generate_content();

    }

    /**
     * Generates a Page, Post or CPT
     *
     * @since   1.6.1
     */
    public function generate_content() {

        // Validate
        $group = $this->generate_validation();

        /**
         * Runs any actions before Generate Content has started.
         *
         * @since   1.9.9
         *
         * @param   int     $group_id   Group ID
         * @param   bool    $test_mode  Test Mode
         */
        do_action( 'gpt_press_generate_content_before', $group['group_id'], $group['test_mode'] );

        // Run
        $start  = microtime( true );
        $result = $this->base->get_class( 'generate' )->generate_content( $group['group_id'], $group['current_index'], $group['test_mode'] );
        $end    = microtime( true );

        /**
         * Runs any actions once Generate Content has finished.
         *
         * @since   1.9.3
         *
         * @param   int     $group_id   Group ID
         * @param   bool    $test_mode  Test Mode
         */
        do_action( 'gpt_press_generate_content_after', $group['group_id'], $group['test_mode'] );

        // Return
        $this->generate_return( $result, $start, $end );

    } 

    /**
     * Trashes all Generated Content
     *
     * @since   1.9.1
     */
    public function trash_generated_content() {

        // Validate
        $group = $this->generate_validation();

        // Run
        $result = $this->base->get_class( 'generate' )->trash_content( $group['group_id'] );

        // Return
        $this->generate_return( $result );

    }

    /**
     * Deletes all Generated Content
     *
     * @since   1.8.4
     */
    public function delete_generated_content() {

        // Validate
        $group = $this->generate_validation();

        // Run
        $result = $this->base->get_class( 'generate' )->delete_content( $group['group_id'] );

        // Return
        $this->generate_return( $result );

    }

    /**
     * Removes the generating flag on the Group, as Generation has finished.
     *
     * @since   1.9.9
     */
    public function finished_generated_content() {

        // Validate
        $group = $this->generate_validation();

        // Run
        $result = $this->base->get_class( 'groups' )->stop_generation( $group['group_id'] );

        // Return
        $this->generate_return( $result );

    }

    /**
     * Runs validation when AJAX calls are made to generate content or terms,
     * returning the Group ID and Current Index.
     *
     * @since   1.6.1
     *
     * @return  array   Group ID and Current Index
     */
    private function generate_validation() {

        // Sanitize inputs
        if ( ! isset( $_POST['id'] ) ) {
            wp_send_json_error( __( 'No group ID was specified!', 'gpt-press' ) );
            die();
        }
        
        return array(
            'group_id'      => absint( $_POST['id'] ),
            'current_index' => ( isset( $_POST['current_index'] ) ? absint( $_POST['current_index'] ) : 0 ),
            'test_mode'     => ( isset( $_POST['test_mode'] ) ? true : false ),
        );

    }

    /**
     * Returns the generation result as a JSON error or success
     *
     * @since   1.6.1
     *
     * @param   mixed   $result     WP_Error | array
     */
    private function generate_return( $result ) {

        // Return error or success JSON
        if ( is_wp_error( $result ) ) {
            wp_send_json_error( $result->get_error_code() . ': ' . $result->get_error_message() );
        }

        // If here, run routine worked
        wp_send_json_success( $result );

    }

}