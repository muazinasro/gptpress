<?php
/**
 * Common class
 * 
 * @package Page Generator Pro
 * @author  Tim Carr
 * @version 1.0.0
 */
class Gpt_Press_Pro_Common {

    /**
     * Holds the base object.
     *
     * @since   1.9.8
     *
     * @var     object
     */
    public $base;

    /**
     * Constructor
     * 
     * @since   1.9.8
     *
     * @param   object $base    Base Plugin Class
     */
    public function __construct( $base ) {

        // Store base class
        $this->base = $base;

    }

    /**
     * Helper method to retrieve Generation Systems
     *
     * @since   2.6.1
     *
     * @return  array   Generation Systems
     */
    public function get_generation_systems() {

        // Get systems
        $systems = array(
            'browser'   => __( 'Browser', 'gpt-press-pro' ),
        );

        /**
         * Defines available Generation Systems
         *
         * @since   2.6.1
         *
         * @param   array   $systems    Generation Systems
         */
        $systems = apply_filters( 'gpt_press_pro_common_get_generation_systems', $systems );

        // Return filtered results
        return $systems;

    }

    /**
     * Helper method to retrieve authors
     *
     * @since   1.1.3
     *
     * @return  array   Authors
     */
    public function get_authors() {

        // Get authors
        $authors = get_users( array(
             'orderby' => 'nicename',
        ) );

        /**
         * Defines available authors for the Author dropdown on the Generate Content screen.
         *
         * @since   1.1.3
         *
         * @param   array   $authors    Authors
         */
        $authors = apply_filters( 'gpt_press_pro_common_get_authors', $authors );

        // Return filtered results
        return $authors;
        
    }

    /**
     * Helper method to retrieve post statuses
     *
     * @since   1.1.3
     *
     * @return  array   Post Statuses
     */
    public function get_post_statuses() {

        // Get statuses
        $statuses = array(
            'draft'     => __( 'Draft', 'gpt-press' ),
            'private'   => __( 'Private', 'gpt-press' ),
            'publish'   => __( 'Publish', 'gpt-press' ),
        );

        /**
         * Defines available Post Statuses for generated content.
         *
         * @since   1.1.3
         *
         * @param   array   $statuses   Statuses
         */
        $statuses = apply_filters( 'gpt_press_pro_common_get_post_statuses', $statuses );

        // Return filtered results
        return $statuses;
        
    }

    /**
     * Returns an array of Javascript DOM selectors to enable the keyword
     * autocomplete functionality on.
     *
     * @since   2.0.2
     *
     * @return  array   Javascript DOM Selectors
     */
    public function get_autocomplete_enabled_fields() {

        // Get fields
        $fields = array(
            // Classic Editor
            'input[name=post_title]',
            'input[name=tag-name]',
            'input[name=name]',
            'input[name=slug]',
            'textarea[name=description]',

            // Gutenberg
            'textarea.editor-post-title__input', // Post Title
            'div.wpzinc-autocomplete input[type=text]',
            
            // Classic Editor and Plugin Fields
            'input.wpzinc-autocomplete',
        );

        /**
         * Defines an array of Javascript DOM selectors to enable the keyword
         * autocomplete functionality on.
         *
         * @since   2.0.2
         *
         * @param   array   $fields  Supported Fields
         */
        $fields = apply_filters( 'gpt_press_pro_common_get_autocomplete_enabled_fields', $fields );

        // Return filtered results
        return $fields;

    }

    /**
     * Returns an array of Javascript DOM selectors to enable the
     * selectize functionality on.
     *
     * @since   2.5.4
     *
     * @return  array   Javascript DOM Selectors
     */
    public function get_selectize_enabled_fields() {

        // Get fields
        $fields = array(
            'freeform' => array(
                'input.wpzinc-selectize-freeform',
                '.wpzinc-selectize-freeform input',
            ),

            'drag_drop' => array(
                'select.wpzinc-selectize-drag-drop',
                '.wpzinc-selectize-drag-drop select',
            ),

            'search' => array(
                'select.wpzinc-selectize-search',
                '.wpzinc-selectize-search select',
            ),

            'api' => array(
                'select.wpzinc-selectize-api',
                '.wpzinc-selectize-api select',
            ),

            'standard' => array(
                'select.wpzinc-selectize',
                '.wpzinc-selectize select',
            ),
        );

        /**
         * Defines an array of Javascript DOM selectors to enable the
         * selectize functionality on.
         *
         * @since   2.5.4
         *
         * @param   array   $fields  Supported Fields
         */
        $fields = apply_filters( 'gpt_press_pro_common_get_selectize_enabled_fields', $fields );

        // Return filtered results
        return $fields;

    }

    /**
     * Helper method to return an array of WordPress Role Capabilities that should be disabled
     * when a Content Group is Generating Content
     *
     * @since   1.9.9
     *
     * @return  array   Capabilities
     */
    public function get_capabilities_to_disable_on_group_content_generation() {

        // Get capabilities
        $capabilities = array(
            'delete_post',
            'edit_post',
        );

        /**
         * Defines Role Capabilities that should be disabled when a Content Group is Generating Content.
         *
         * @since   1.9.9
         *
         * @param   array   $capabilities   Capabilities
         */
        $capabilities = apply_filters( 'gpt_press_pro_common_get_capabilities_to_disable_on_group_content_generation', $capabilities );

        // Return filtered results
        return $capabilities;

    }

}