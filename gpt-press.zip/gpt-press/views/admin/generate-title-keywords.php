<!-- Keywords -->
<div id="keywords-title">
	<?php $this->base->get_class( 'keywords' )->output_dropdown( $this->keywords, 'title' ); ?>
</div>