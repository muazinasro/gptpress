<div class="wrap">
    <h1 class="wp-heading-inline">
        <?php echo $this->base->plugin->displayName; ?>

        <span>
            <?php echo sprintf( __( 'Generating &quot;%s&quot;', 'gpt-press-pro' ), $settings['title'] ); ?>
        </span>
    </h1>

    <hr class="wp-header-end" />

    <div class="wrap-inner">
        <p>
            <?php 
            echo sprintf( 
                __( '<strong>Mohon Menunggu, GptPress sedang bekerja untuk membuat Artikel Gemini AI secara Massal, Jangan ditutup sampai Selesai</strong>', 'gpt-press-pro' ),
            );
            ?>
            <br />

            <?php _e( 'Sambil Nunggu Artikel dibuat oleh GptPress, Bisa Anda Tinggal Ngopi sambil buka Tab lain Nonton Youtube atau Bukan GptPress di Domain buat Grab juga, Hehehe... Bebaslah...', 'gpt-press-pro' ); ?>
        </p>

        <!-- Progress Bar -->
        <div id="progress-bar"></div>
        <div id="progress">
            <span id="progress-number">0</span>
            <span> / <?php echo $settings['numberOfPosts']; ?></span>
        </div>

        <!-- Status Updates -->
        <div id="log">
            <ul></ul>
        </div>

        <p>
            <!-- Cancel Button -->
            <a href="post.php?post=<?php echo $id; ?>&amp;action=edit" class="button wpzinc-button-red gpt-press-pro-generate-cancel-button">
                <?php _e( 'Berhentikan!', 'gpt-press-pro' ); ?>
            </a>

            <!-- Return Button (display when generation routine finishes -->
            <a href="<?php echo $return_url; ?>" class="button button-primary gpt-press-pro-generate-return-button">
                <?php _e( 'Kembali ke Pengaturan Template', 'gpt-press-pro' ); ?>
            </a>
        </p>
    </div>

    <!-- Triggers AJAX request to run numberOfPosts -->
    <script type="text/javascript">
        jQuery( document ).ready( function( $ ) {

            var gpt_press_pro_cancelled = false,
                gpt_press_pro_generate_stop_on_error = <?php echo $settings['stop_on_error']; ?>,
                gpt_press_pro_generate_stop_on_error_pause = <?php echo ( $settings['stop_on_error_pause'] * 1000 ); ?>,
                gpt_press_pro_number_of_requests = <?php echo ( $settings['numberOfPosts'] + $settings['resumeIndex'] ); ?>;
            
            $('#progress-bar').synchronous_request( {
                url:                ajaxurl,
                number_requests:    gpt_press_pro_number_of_requests,
                offset:             <?php echo $settings['resumeIndex']; ?>,
                data: {
                    id:     <?php echo $id; ?>,
                    action: 'gpt_press_pro_generate_<?php echo $type; ?>'   
                },
                wait: gpt_press_pro_generate_stop_on_error_pause,
                stop_on_error: gpt_press_pro_generate_stop_on_error,
                onRequestSuccess: function( response, currentIndex ) {

                    if ( response.success ) {
                        // Define message and CSS class
                        var message = response.data.message + ' <a href="' + response.data.url + '" target="_blank">' + response.data.url + '</a><br />Waktu: ' + response.data.duration + ' detik. Memory Terpakai/ Batas Memory: ' + response.data.memory_usage + '/' + response.data.memory_peak_usage + 'MB',
                            css_class = ( response.data.generated ? 'success' : 'warning' );

                        for ( var keyword in response.data.keywords_terms ) {
                            message += '<br />{' + keyword + '}: ' + response.data.keywords_terms[ keyword ];
                        }

                        // Output Log
                        $( '#log ul' ).append( '<li class="' + css_class + '">' + ( currentIndex + 1 ) + '/' + gpt_press_pro_number_of_requests + ': ' + message + '</li>' );
                    } else {
                        // Something went wrong
                        // Define message
                        var message = ( currentIndex + 1 ) + '/' + gpt_press_pro_number_of_requests + ': Response Error: ' + response.data;
                        switch ( gpt_press_pro_generate_stop_on_error ) {
                            // Stop
                            case 1:
                                break;

                            // Continue, attempting to regenerate the Content or Term again
                            case 0:
                                message = message + '. Waiting ' + ( gpt_press_pro_generate_stop_on_error_pause / 1000 ) + ' seconds before attempting to regenerate this item.';
                                break;

                            // Continue, skipping the failed Content or Term
                            case -1:
                                message = message + '. Waiting ' + ( gpt_press_pro_generate_stop_on_error_pause / 1000 ) + ' seconds before generating the next item.';
                                break;
                        }

                        // Output Log
                        $( '#log ul' ).append( '<li class="error">' + message + '</li>' ); 
                    }

                    // Run the next request, unless the user clicked the 'Stop Generation' button
                    if ( gpt_press_pro_cancelled == true ) {
                        return false;
                    }

                    // Run the next request
                    return true;

                },

                onRequestError: function( xhr, textStatus, e, currentIndex ) {

                    // Output Log
                    $( '#log ul' ).append( '<li class="error">' + ( currentIndex + 1 )  + '/' + gpt_press_pro_number_of_requests + ': Request Error: ' + xhr.status + ' ' + xhr.statusText + '</li>' );

                    // Run the next request, unless the user clicked the 'Stop Generation' button
                    if ( gpt_press_pro_cancelled == true ) {
                        return false;
                    }

                    // Try again
                    return true;

                },

                onFinished: function() {

                    // If the user clicked the 'Stop Generation' button, show that in the log.
                    if ( gpt_press_pro_cancelled == true ) {
                        $( '#log ul' ).append( '<li class="success">Process cancelled by user</li>' );
                    } else {
                        $( '#log ul' ).append( '<li class="success">Finished</li>' );
                    }

                    // Hide the 'Stop Generation' button
                    $( 'a.gpt-press-pro-generate-cancel-button' ).hide();

                    // Show the 'Return to Group' button
                    $( 'a.gpt-press-pro-generate-return-button' ).removeClass( 'gpt-press-pro-generate-return-button' );

                    // Send an AJAX request to remove the generating flag on the Group
                    $.ajax( {
                        url:        ajaxurl,
                        type:       'POST',
                        async:      true,
                        data:      {
                            id:     <?php echo $id; ?>,
                            action: 'gpt_press_pro_generate_<?php echo $type; ?>_finished'   
                        },
                        error: function( a, b, c ) {
                        },
                        success: function( result ) {
                        }
                    } );

                }
            } );

            // Sets the gpt_press_pro_cancelled flag to true when the user clicks the 'Stop Generation' button
            $( 'a.gpt-press-pro-generate-cancel-button' ).on( 'click', function( e ) {
                e.preventDefault();
                gpt_press_pro_cancelled = true;
            } );
        } );  
    </script>
</div>