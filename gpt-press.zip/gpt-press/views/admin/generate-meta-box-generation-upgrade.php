<div class="wpzinc-option highlight">
    <div class="full">
        <h4><?php _e( 'Methods and Overwriting', 'gpt-press' ); ?></h4>

        <p>
        	<?php 
        	_e( 'Generate Pages for all possible keyword combinations, and choose whether to overwrite or skip Page Generation
        	if content already exists.', 'gpt-press' );
        	?>
        </p>
    </div>
</div>