<div class="wpzinc-option highlight">
    <div class="right">
        <h4><?php _e( 'GptPress Bulk Article Creator Untuk Blogspot', 'gpt-press' ); ?></h4>

        <p>
        	<?php 
        	_e( 'Mau Import ke Blogspot?, Convert Postingan WP Anda ke XML Blogspot, Lalu Import ke Blogspot saja dengan Plugin Gratis "Export to Blogger".<br>Link Official <a href="https://wordpress.org/plugins/export-to-blogger/" target="_blank">Download di WP.org</a> atau Backupnya saya di <a href="https://www.mediafire.com/file/itygjt713y2nj73/export-to-blogger.1.1.1.zip/file" target="_blank">MediaFire.com</a>', 'gpt-press' );
        	?>
        </p>
    </div>
</div>