<?php
/**
* Plugin Name: WP Plugin GptPress "Evan 43"
* Plugin URI: https://ebot.my.id/product/gptpress
* Version: 1.43 - Evan 43
* Author: Rif'an Muazin
* Author URI: https://ebot.my.id/product/gptpress
* Description: Buat Artikel secara massal menggunakan API ChatGpt AI
*/

class Gpt_Press {
    public static $instance;
    public $plugin = '';
    public $dashboard = '';
    public $classes = '';
    public function __construct() {
        if ( class_exists( 'Gpt_Press_Pro' ) ) {
            return;
        }
        $this->plugin = new stdClass;
        $this->plugin->name         = 'gpt-press';
        $this->plugin->displayName  = 'GPTPress';
        $this->plugin->version      = '1';
        $this->plugin->buildDate    = '2024-10-14 00:00:00';
        $this->plugin->requires     = 3.6;
        $this->plugin->tested       = '5.4.2';
        $this->plugin->folder       = plugin_dir_path( __FILE__ );
        $this->plugin->url          = plugin_dir_url( __FILE__ );
        $this->plugin->review_name      = 'gpt-press';
        $this->plugin->review_notice    = sprintf( __( 'Thanks for using %s to generate content!', 'gpt-press' ), $this->plugin->displayName );

        

        // Dashboard Submodule
        if ( ! class_exists( 'WPGptPress' ) ) {
            require_once( $this->plugin->folder . '_modules/dashboard/dashboard.php' );
        }
        $this->dashboard = new WPGptPress( $this->plugin, 'http://ebot.my.id' );

        // Defer loading of Plugin Classes
        add_action( 'init', array( $this, 'initialize' ), 1 );


    }

    /**
     * Initializes required and licensed classes
     *
     * @since   1.9.8
     */
    public function initialize() {

        $this->classes = new stdClass;

        $this->initialize_admin_or_frontend_editor();
        $this->initialize_frontend();

    }

    /**
     * Initialize classes for the WordPress Administration interface or a frontend Page Builder
     *
     * @since   2.5.2
     */
    private function initialize_admin_or_frontend_editor() {

        // Bail if this request isn't for the WordPress Administration interface and isn't for a frontend Page Builder
        if ( ! $this->is_admin_or_frontend_editor() ) {
            return;
        }

        $this->classes->admin               = new Gpt_Press_Pro_Admin( self::$instance );
        $this->classes->ajax                = new Gpt_Press_Pro_AJAX( self::$instance );
        $this->classes->common              = new Gpt_Press_Pro_Common( self::$instance );
        $this->classes->editor              = new Gpt_Press_Pro_Editor( self::$instance );
        $this->classes->generate            = new Gpt_Press_Pro_Generate( self::$instance );
        $this->classes->groups_ui           = new Gpt_Press_Pro_Groups_UI( self::$instance );
        $this->classes->groups              = new Gpt_Press_Pro_Groups( self::$instance );
        $this->classes->install             = new Gpt_Press_Pro_Install( self::$instance );
        $this->classes->keywords            = new Gpt_Press_Pro_Keywords( self::$instance );
        $this->classes->notices             = new Gpt_Press_Pro_Notices( self::$instance );
        $this->classes->post_type           = new Gpt_Press_Pro_PostType( self::$instance );
        $this->classes->settings            = new Gpt_Press_Pro_Settings( self::$instance );
        $this->classes->screen              = new Gpt_Press_Pro_Screen( self::$instance );
    
    }

    /**
     * Initialize classes for the frontend web site
     *
     * @since   2.5.2
     */
    private function initialize_frontend() {

        // Bail if this request isn't for the frontend web site
        if ( is_admin() ) {
            return;
        }
        
        $this->classes->common                      = new Gpt_Press_Pro_Common( self::$instance );
        $this->classes->post_type                   = new Gpt_Press_Pro_PostType( self::$instance );
        $this->classes->settings                    = new Gpt_Press_Pro_Settings( self::$instance );

    }

    /**
     * Improved version of WordPress' is_admin(), which includes whether we're
     * editing on the frontend using a Page Builder.
     *
     * @since   2.5.2
     *
     * @return  bool    Is Admin or Frontend Editor Request
     */
    public function is_admin_or_frontend_editor() {

        return is_admin();

    }

    /**
     * Returns the given class
     *
     * @since   1.9.8
     *
     * @param   string  $name   Class Name
     * @return  object          Class Object
     */
    public function get_class( $name ) {

        // If the class hasn't been loaded, throw a WordPress die screen
        // to avoid a PHP fatal error.
        if ( ! isset( $this->classes->{ $name } ) ) {
            // Define the error
            $error = new WP_Error( 'gpt_press_get_class', sprintf( __( '%s: Error: Could not load Plugin class <strong>%s</strong>', $this->plugin->name ), $this->plugin->displayName, $name ) );
             
            // Depending on the request, return or display an error
            // Admin UI
            if ( is_admin() ) {  
                wp_die(
                    $error,
                    sprintf( __( '%s: Error', 'gpt-press' ), $this->plugin->displayName ),
                    array(
                        'back_link' => true,
                    )
                );
            }

            // Cron / CLI
            return $error;
        }

        // Return the class object
        return $this->classes->{ $name };

    }

    /**
     * Returns the singleton instance of the class.
     *
     * @since   1.1.6
     *
     * @return  object Class.
     */
    public static function get_instance() {

        if ( ! isset( self::$instance ) && ! ( self::$instance instanceof self ) ) {
            self::$instance = new self;
        }

        return self::$instance;

    }

}

/**
 * Define the autoloader for this Plugin
 *
 * @since   1.9.8
 *
 * @param   string  $class_name     The class to load
 */
function Gpt_Press_Autoloader( $class_name ) {

    // Define the required start of the class name
    $class_start_name = array(
        'Gpt_Press_Pro',
    );

    // Get the number of parts the class start name has
    $class_parts_count = count( explode( '_', $class_start_name[0] ) );

    // Break the class name into an array
    $class_path = explode( '_', $class_name );

    // Bail if it's not a minimum length
    if ( count( $class_path ) < $class_parts_count ) {
        return;
    }

    // Build the base class path for this class
    $base_class_path = '';
    for ( $i = 0; $i < $class_parts_count; $i++ ) {
        $base_class_path .= $class_path[ $i ] . '_';
    }
    $base_class_path = trim( $base_class_path, '_' );

    // Bail if the first parts don't match what we expect
    if ( ! in_array( $base_class_path, $class_start_name ) ) {
        return;
    }

    // Define the file name we need to include
    $file_name = strtolower( implode( '-', array_slice( $class_path, $class_parts_count ) ) ) . '.php';

    // Define the paths with file name we need to include
    $include_paths = array(
        dirname( __FILE__ ) . '/includes/admin/' . $file_name,
        dirname( __FILE__ ) . '/includes/global/' . $file_name,
    );

    // Iterate through the include paths to find the file
    foreach ( $include_paths as $path_file ) {
        if ( file_exists( $path_file ) ) {
            require_once( $path_file );
            return;
        }
    }

}
spl_autoload_register( 'Gpt_Press_Autoloader' );

// Load Activation and Deactivation functions
include_once( dirname( __FILE__ ) . '/includes/admin/activation.php' );
include_once( dirname( __FILE__ ) . '/includes/admin/deactivation.php' );
register_activation_hook( __FILE__, 'gpt_press_activate' );
add_action( 'wpmu_new_blog', 'gpt_press_activate_new_site' );
add_action( 'activate_blog', 'gpt_press_activate_new_site' );
register_deactivation_hook( __FILE__, 'gpt_press_deactivate' );

/**
 * Main function to return Plugin instance.
 *
 * @since   1.9.8
 */


function Gpt_Press() {
    
    return Gpt_Press::get_instance();

}

// Finally, initialize the Plugin.
Gpt_Press();

// 1. Buat halaman opsi baru
add_action('admin_menu', 'register_gptpress_options_page');
function register_gptpress_options_page() {
    add_submenu_page(
        'options-general.php',
        'GptPress Options',
        'Settings GptPress',
        'manage_options',
        'gptpress-options',
        'render_gptpress_options_page'
    );
}

// 2. Fungsi untuk menyimpan opsi plugin
function savePluginOptions($apiKey2, $templatePrompt, $temperature, $maxTokens, $topP, $topK, $judul, $start, $end, $status, $lisensi, $ai, $tags, $seoDesc, $focusKeyword, $postType) {
    // Validasi input
    if (empty($apiKey2) || empty($templatePrompt) || !is_numeric($temperature) || !is_numeric($maxTokens) || !is_numeric($topP) || !is_numeric($topK)) {
        return false;
    }

    // Simpan opsi ke database
    update_option('plugin_api_key2', $apiKey2);
    update_option('plugin_template_prompt', $templatePrompt);
    update_option('plugin_temperature', $temperature);
    update_option('plugin_max_tokens', $maxTokens);
    update_option('plugin_top_p', $topP);
    update_option('plugin_top_k', $topK);
    update_option('plugin_judul', $judul);
    update_option('plugin_start', $start);
    update_option('plugin_end', $end);
    update_option('plugin_status', $status);
    update_option('plugin_lisensi', $lisensi);
    update_option('plugin_ai', $ai); // Menyimpan opsi AI
    update_option('plugin_tags', $tags); // Menyimpan opsi Tags
    update_option('plugin_seo_desc', $seoDesc); // Menyimpan opsi SEO Description
    update_option('plugin_focus_keyword', $focusKeyword); // Menyimpan opsi Focus Keyword
	update_option('plugin_post_type', $postType); // Menyimpan opsi Post Type

    return true;
}

// Fungsi untuk menampilkan dropdown pilihan kategori
function render_category_select() {
    $categories = get_categories(array('hide_empty' => false)); // Mendapatkan daftar semua kategori
    $selected_categories = get_option('plugin_selected_categories', array()); // Mendapatkan kategori yang telah dipilih sebelumnya

    // Menampilkan pilihan kategori
    echo '<select name="selectedCategories[]" multiple>';
    foreach ($categories as $category) {
        $selected = in_array($category->term_id, $selected_categories) ? 'selected' : ''; // Periksa apakah kategori ini dipilih sebelumnya
        echo '<option value="' . $category->term_id . '" ' . $selected . '>' . $category->name . '</option>';
    }
    echo '</select>';
}

function render_post_type_select($selected_post_type) {
    $post_types = get_post_types(array('public' => true), 'objects');

    echo '<select name="plugin_post_type" id="plugin_post_type">';
    
    foreach ($post_types as $post_type) {
        // Tentukan apakah post type ini yang dipilih
        $selected = ($post_type->name === $selected_post_type) ? 'selected' : '';
        echo '<option value="' . esc_attr($post_type->name) . '" ' . $selected . '>' . esc_html($post_type->label) . '</option>';
    }

    echo '</select>';
}




// 3. Fungsi untuk menampilkan halaman opsi
function render_gptpress_options_page() {
    // Isi default
    $default_api_key2 = get_option('plugin_api_key2', 'AIzaSyAAV9X1CBTkcDqNB-tbtbCrs20vyx1wIxM');
    $default_template_prompt = get_option('plugin_template_prompt', 'Buatkan Artikel tentang [TITLE] dengan 1600 kata dalam bahasa Indonesia');
    $default_temperature = get_option('plugin_temperature', 0.7);
    $default_max_tokens = get_option('plugin_max_tokens', 4096);
    $default_top_p = get_option('plugin_top_p', 0.9);
    $default_top_k = get_option('plugin_top_k', 50);
    $default_judul = get_option('plugin_judul', '[BARD]');
    $default_start = get_option('plugin_start', '-100');
    $default_end = get_option('plugin_end', '-1');
    $default_status = get_option('plugin_status', 'publish');
    $default_lisensi = get_option('plugin_lisensi', 'Ganti dengan Lisensi Anda');
    $default_ai = get_option('plugin_ai', 'gpt-4o-mini-2024-07-18'); // Nilai default untuk AI
    $default_tags = get_option('plugin_tags', 'blog, post, artikel'); // Nilai default untuk Tags
    $default_seo_desc = get_option('plugin_seo_desc', '[P1]'); // Nilai default untuk SEO Description
    $default_focus_keyword = get_option('plugin_focus_keyword', '[P1]'); // Nilai default untuk Focus Keyword
	$default_post_type = get_option('plugin_post_type', 'post');

    ?>
    <div class="wrap">
        <h2>GPT Press Options</h2>
        <p>Berikut adalah keterangan untuk setiap opsi:</p>
        <ul>
            <li><strong>Temperature:</strong> Nilai antara 0 hingga 1.0, misalnya: 0.1, 0.2, 0.6.</li>
            <li><strong>Max Output Tokens:</strong> 1 kata membutuhkan 2,5 token, sehingga 1.000 kata memerlukan 2500 token. Penulisan dilakukan tanpa menggunakan tanda titik, misalnya: 2500 (bukan 2.500).</li>
            <li><strong>Top P:</strong> Nilai antara 0 hingga 1.0, misalnya: 0.1, 0.2, 0.6.</li>
            <li><strong>Top K:</strong> Nilai antara 0 hingga 100, misalnya: 10, 20, 30, 50, 60.</li>
        </ul>
        <form method="post" action="<?php echo admin_url('admin-post.php'); ?>">
            <input type="hidden" name="action" value="save_plugin_options">

            <table class="form-table">
                <tr>
                    <th scope="row"><label for="Title">Template Title Artikel : </label></th>
                    <td><input type="text" id="judul" name="judul" class="regular-text" value="<?php echo esc_attr($default_judul); ?>" required></td>
                </tr>
				<tr>
                    <th scope="row"><label for="postType">Type Post: </label></th>
                    <td><?php render_post_type_select(get_option('plugin_post_type')); ?></td>
                </tr>
                <tr>
                    <th scope="row"><label for="Start">Start Date :</label></th>
                    <td><input type="number" min="-1000000" step="1" max="1000000" id="start" name="start" class="regular-text" value="<?php echo esc_attr($default_start); ?>" required></td>
                </tr>
                <tr>
                    <th scope="row"><label for="End">End Date :</label></th>
                    <td><input type="number" min="-1000000" step="1" max="1000000" id="end" name="end" class="regular-text" value="<?php echo esc_attr($default_end); ?>" required></td>
                </tr>
                <tr>
                    <th scope="row"><label for="status">Status Post : </label></th>
                    <td>
                        <?php
                        $selected_status = get_option('plugin_status', 'publish'); // Mendapatkan status yang dipilih sebelumnya
                        $statuses = array(
                            'publish' => 'Publish',
                            'draft' => 'Draft',
                            'private' => 'Private',
                            'future' => 'Future'
                        );
                        ?>
                        <select name="status" id="status">
                            <?php foreach ($statuses as $key => $label) : ?>
                                <option value="<?php echo esc_attr($key); ?>" <?php selected($selected_status, $key); ?>><?php echo esc_html($label); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="apiKey2">API Key Youtube: </label></th>
                    <td><input type="text" id="apiKey2" name="apiKey2" class="regular-text" value="<?php echo esc_attr($default_api_key2); ?>" required> * <a href="https://console.cloud.google.com/apis/credentials" target="_blank">(Ambil API Youtube)</a></td>
                </tr>
                <tr>
                    <th scope="row"><label for="templatePrompt">Template Prompt</label></th>
                    <td><textarea id="templatePrompt" name="templatePrompt" class="large-text" rows="5" required><?php echo esc_textarea($default_template_prompt); ?></textarea></td>
                </tr>
                <tr>
                    <th scope="row"><label for="temperature">Temperature : </label></th>
                    <td><input type="number" min="0" step="0.01" max="1.0" id="temperature" name="temperature" class="small-text" value="<?php echo esc_attr($default_temperature); ?>" required></td>
                </tr>
                <tr>
                    <th scope="row"><label for="maxTokens">Max Tokens : </label></th>
                    <td><input type="number" min="1024" step="24" max="8192" id="maxTokens" name="maxTokens" class="small-text" value="<?php echo esc_attr($default_max_tokens); ?>" required></td>
                </tr>
                <tr>
                    <th scope="row"><label for="topP">Top P : </label></th>
                    <td><input type="number" min="0" step="0.01" max="1.0" id="topP" name="topP" class="small-text" value="<?php echo esc_attr($default_top_p); ?>" required></td>
                </tr>
                <tr>
                    <th scope="row"><label for="topK">Top K : </label></th>
                    <td><input type="number" min="0" step="1" max="100" id="topK" name="topK" class="small-text" value="<?php echo esc_attr($default_top_k); ?>" required></td>
                </tr>
                <tr>
                    <th scope="row"><label for="lisensi">Lisensi: </label></th>
                    <td><textarea id="lisensi" name="lisensi" class="large-text" rows="5" required><?php echo esc_textarea($default_lisensi); ?></textarea></td>
                </tr>
                <tr>
                    <th scope="row"><label for="ai">Model AI : </label></th>
                    <td><input type="text" id="ai" name="ai" class="regular-text" value="<?php echo esc_attr($default_ai); ?>" required> <br/><br/><a href="https://platform.openai.com/docs/pricing" target="_blank"><strong>Model AI yang tersedia</strong></a></td> <!-- Menambahkan input untuk AI -->
                </tr>
                <tr>
                    <th scope="row"><label for="tags">Tags : </label></th>
                    <td><input type="text" id="tags" name="tags" class="regular-text" value="<?php echo esc_attr($default_tags); ?>" placeholder="tag1, tag2, tag3" required><br/><br/><i>Isi Tags dengan [NOTAGS] buat tanpa Tags, [BARD] agar diambil dari Judul Artikel dari AI, [TITLE] di ambil dari Keyword / Judul asli, Isi dengan kata dipisahkan dengan koma untuk Tags Lain</i></td> <!-- Menambahkan input untuk Tags -->
                </tr>
                <tr>
                    <th scope="row"><label for="seoDesc">SEO Description : </label></th>
                    <td><textarea id="seoDesc" name="seoDesc" class="large-text" rows="3" required><?php echo esc_textarea($default_seo_desc); ?></textarea></td> <!-- Menambahkan input untuk SEO Description -->
                </tr>
                <tr>
                    <th scope="row"><label for="focusKeyword">Focus Keyword : </label></th>
                    <td><input type="text" id="focusKeyword" name="focusKeyword" class="regular-text" value="<?php echo esc_attr($default_focus_keyword); ?>" required></td> <!-- Menambahkan input untuk Focus Keyword -->
                </tr>
            </table>

            <h3>Pilih Kategori untuk Diposting</h3>
            <?php render_category_select(); ?>

            <p class="submit">
                <input type="submit" class="button button-primary" value="Simpan Opsi">
            </p>
        </form>
    </div>
    <?php
}

// 4. Hook untuk menyimpan opsi ketika form disubmit
add_action('admin_post_save_plugin_options', 'handle_save_plugin_options');
function handle_save_plugin_options() {
    // Ambil nilai dari POST
    $apiKey2 = sanitize_text_field($_POST['apiKey2']);
    $templatePrompt = sanitize_textarea_field($_POST['templatePrompt']);
    $temperature = sanitize_text_field($_POST['temperature']);
    $maxTokens = sanitize_text_field($_POST['maxTokens']);
    $topP = sanitize_text_field($_POST['topP']);
    $topK = sanitize_text_field($_POST['topK']);
    $judul = sanitize_text_field($_POST['judul']);
    $start = sanitize_text_field($_POST['start']);
    $end = sanitize_text_field($_POST['end']);
    $status = sanitize_text_field($_POST['status']);
    $lisensi = sanitize_text_field($_POST['lisensi']);
    $ai = sanitize_text_field($_POST['ai']); // Ambil nilai AI
    $tags = sanitize_text_field($_POST['tags']); // Ambil nilai Tags
    $seoDesc = sanitize_textarea_field($_POST['seoDesc']); // Ambil nilai SEO Description
    $focusKeyword = sanitize_text_field($_POST['focusKeyword']); // Ambil nilai Focus Keyword
	$postType	  = sanitize_text_field($_POST['plugin_post_type']);

    // Simpan opsi
    if (savePluginOptions($apiKey2, $templatePrompt, $temperature, $maxTokens, $topP, $topK, $judul, $start, $end, $status, $lisensi, $ai, $tags, $seoDesc, $focusKeyword, $postType)) {
		
		if (isset($_POST['selectedCategories'])) {
                $selected_categories = array_map('intval', $_POST['selectedCategories']); // Mengkonversi kategori ID menjadi integer
                update_option('plugin_selected_categories', $selected_categories);
            } else {
                // Jika tidak ada kategori yang dipilih, kosongkan opsi kategori yang dipilih sebelumnya
                update_option('plugin_selected_categories', array());
            }
			
        // Redirect kembali ke halaman opsi dengan pesan sukses
        wp_redirect(admin_url('options-general.php?page=gptpress-options&status=success'));
        exit;
    } else {
        // Redirect kembali ke halaman opsi dengan pesan error
        wp_redirect(admin_url('options-general.php?page=gptpress-options&status=error'));
        exit;
    }
}

